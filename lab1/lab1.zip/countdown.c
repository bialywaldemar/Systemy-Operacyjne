﻿

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <malloc.h>

int main()
{
    for( int i = 0; i < 11; i++ )
    {
        printf( "%d\n", 10 - i );
    }
    return 0;
}